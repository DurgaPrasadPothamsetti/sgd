package com.cg.bankapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.dao.BankAppDao;
import com.cg.bankapp.exception.BankException;

@Service
public class BankAppServiceImpl implements BankAppService {
	@Autowired
	BankAppDao dao;

	@Override
	public BankApp addCustomer(BankApp bank) throws BankException {
		// TODO Auto-generated method stub
		return dao.save(bank);
	}
	@Override
	public BankApp getDetailsById(int AccountNum) throws BankException {
		// TODO Auto-generated method stub
		return dao.findById(AccountNum).get();
	}

	@Override
	public List<BankApp> getCustomerDetails() throws BankException {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public BankApp loginByUser(String Name, String Password) throws BankException {
		// TODO Auto-generated method stub
		 
		return null;
	}

	@Override
	public long depositMoney(int AccountNum, long amount) throws BankException {
		return 0;
		
		
	}

	@Override
	public long withdrawMoney(int AccountNum, long amount) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BankApp showBalance(int AccountNum) throws BankException {
		
		
		return dao.findById(AccountNum).get();
	}

	@Override
	public boolean fundTransferUpdate(int accountNo1, int accountNo2, long amount) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}


	
	
	

}
