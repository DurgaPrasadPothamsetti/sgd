package com.cg.bankapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.exception.BankException;
import com.cg.bankapp.service.BankAppService;


@CrossOrigin(origins = "http://localhost:2558")
@RestController
public class BankAppController {
	@Autowired
	BankAppService bankService;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public BankApp addCustomer(@RequestBody BankApp bank) throws BankException {
		
		return bankService.addCustomer(bank);
	}
	
	@RequestMapping(value="/get", method = RequestMethod.GET, produces = "application/json")
	public List<BankApp> getCustomerDetails() throws BankException {
		return bankService.getCustomerDetails();
	}
	
	@RequestMapping("/getdetails/{AccountNum}")
	public BankApp getAllProducts(@PathVariable int AccountNum) throws BankException {
		return bankService.getDetailsById(AccountNum);
	}
	@RequestMapping("/getbalance/{AccountNum}")
	public BankApp getBalance(@PathVariable int AccountNum) throws BankException {
		return bankService.showBalance(AccountNum);
	}
	
}
