package com.cg.bankapp.service;



import java.util.List;


import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.exception.BankException;


public interface BankAppService {
		public BankApp addCustomer(BankApp bank) throws BankException;
		public List<BankApp> getCustomerDetails() throws BankException;
	    BankApp getDetailsById(int AccountNum) throws BankException;
	    public BankApp loginByUser(String Name, String Password) throws BankException;
	    
	    public long depositMoney(int AccountNum, long amount) throws BankException;
	    
	    public long withdrawMoney(int AccountNum,long amount) throws BankException;
	    
	    public BankApp showBalance(int AccountNum) throws BankException;
	    
	    public boolean fundTransferUpdate(int accountNo1,int accountNo2,long amount) throws BankException;
		
}
