package com.cg.bankapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BANKAPP")
public class BankApp {
	@Id
	@Column(name="ACCOUNTNUM")
	private int AccountNum;
	
	@Column(name="NAME")
	private String Name;
	
	@Column(name="CITY")
	private String City;
	
	@Column(name="PASSWORD")
	private String Password;
	
	@Column(name="MOBILE")
	private String Mobile;
	
	@Column(name="BALANCE")
	private long Balance;
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}

	public long getBalance() {
		return Balance;
	}
	public void setBalance(long balance) {
		Balance = balance;
	}
	public int getAccountNum() {
		return AccountNum;
	}
	public void setAccountNum(int accountNum) {
		AccountNum = accountNum;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	@Override
	public String toString() {
		return "BankApp [AccountNum=" + AccountNum + ", Name=" + Name + ", City=" + City + ", Password=" + Password
				+ ", Mobile=" + Mobile + ", Balance=" + Balance + "]";
	}
	
	
	
	
	
	
	
		
}
