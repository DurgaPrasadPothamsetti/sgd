package com.cg.bankapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bankapp.bean.BankApp;
@Repository
public interface BankAppDao extends JpaRepository<BankApp, Integer>{

}
