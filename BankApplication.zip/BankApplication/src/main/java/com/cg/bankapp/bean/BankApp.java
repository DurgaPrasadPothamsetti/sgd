package com.cg.bankapp.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class BankApp {
	@Id
	private int AccountNum;
	private String Name;
	private String City;
	private String Password;
	private String Mobile;
	private long Balance;
	
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public void setBalance(long balance) {
		Balance = balance;
	}
	public int getAccountNum() {
		return AccountNum;
	}
	public void setAccountNum(int accountNum) {
		AccountNum = accountNum;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getMobile() {
		return Mobile;
	}
	public void setMobile(String mobile) {
		Mobile = mobile;
	}
	
	@Override
	public String toString() {
		return "BankApp [AccountNum=" + AccountNum + ", Name=" + Name + ", Balance=" + Balance + "]";
	}
	
	
	
	
	
	
		
}
