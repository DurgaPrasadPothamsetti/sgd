package com.cg.bankapp.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class BankAppController {

}
