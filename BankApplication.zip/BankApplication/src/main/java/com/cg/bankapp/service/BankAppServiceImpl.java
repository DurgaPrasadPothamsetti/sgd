package com.cg.bankapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapp.bean.BankApp;
import com.cg.bankapp.dao.BankAppDao;
import com.cg.bankapp.exception.BankException;

@Service
public class BankAppServiceImpl implements BankAppService {
	@Autowired
	BankAppDao dao;

	@Override
	public boolean addCustomer(BankApp bank) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public BankApp getCustomerDetails(String Name) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BankApp loginByUser(String Name, String Password) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long depositMoney(int AccountNum, long amount) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long withdrawMoney(int AccountNum, long amount) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public long showBalance(int AccountNum) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean fundTransferUpdate(int accountNo1, int accountNo2, long amount) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
